Brighter Tommorrow Charity

شبکه مهربانی


BTC.pdf => مستندات و تحلیل های مربوط به پروژه
https://github.com/Bilal00Rock/BTC.git => لینک گیت هاب پروژه 

اعضای گروه: 
بلال سپاهی => Backend
محمد یاسین بلوچی => frontend
امیر مهدی امیر تیموری => frontend

با تشکر